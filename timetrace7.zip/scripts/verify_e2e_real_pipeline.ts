import fs from 'fs';
import path from 'path';
import { spawn, ChildProcess } from 'child_process';

const SERVER_BASE = 'http://localhost:3000';
const AGENT_BRIDGE_URL = 'http://127.0.0.1:9876/api/browser-event';
const AGENT_STATUS_URL = 'http://127.0.0.1:9876';

async function request(url: string, options: any = {}) {
  const res = await fetch(url, options);
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: res.status, headers: res.headers, text, json };
}

async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForAgentPort(timeoutMs = 10000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const ping = await request(AGENT_STATUS_URL);
      if (ping.status === 200) return true;
    } catch {}
    await sleep(400);
  }
  return false;
}

async function runRealWorldPipelineVerification() {
  console.log('================================================================');
  console.log(' CHRONOTRACE END-TO-END PIPELINE VERIFICATION ON WINDOWS / AGENT');
  console.log('================================================================\n');

  const today = new Date().toISOString().split('T')[0];

  // 1. Register a clean test user to ensure 100% data isolation
  const randId = Math.floor(10000 + Math.random() * 90000);
  const regRes = await request(`${SERVER_BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: `tester${randId}`,
      email: `tester${randId}@example.com`,
      name: 'Pipeline Tester',
      password: 'Password123!',
      confirmPassword: 'Password123!',
    }),
  });

  if (regRes.status !== 200 && regRes.status !== 201) {
    throw new Error(`Failed to create test user: ${regRes.text}`);
  }

  const user = regRes.json.user;
  const sessionToken = regRes.json.sessionToken || regRes.json.token;
  const authHeaders = {
    'Authorization': `Bearer ${sessionToken}`,
    'x-session-token': sessionToken,
    'Cookie': `chronotrace_session=${sessionToken}`,
  };
  const deviceToken = user.deviceToken;

  console.log(`[AUTH] Test user created: ${user.username} (${user.id})`);
  console.log(`[AUTH] Device Token: ${deviceToken.slice(0, 10)}...`);

  // -------------------------------------------------------------
  // STEP 1: Verify Chrome Extension Package and Privacy Guarantees
  // -------------------------------------------------------------
  console.log('\n--> Step 1: Downloading and verifying Chrome Extension package...');
  const extDownloadRes = await request(`${SERVER_BASE}/api/download-extension?token=${deviceToken}`);
  if (extDownloadRes.status !== 200) {
    throw new Error(`Failed to download extension: ${extDownloadRes.status}`);
  }
  console.log(`[PASS] Extension ZIP received (${extDownloadRes.text.length} raw bytes)`);

  // Inspect source files directly in repository for privacy compliance
  const contentJs = fs.readFileSync(path.join(process.cwd(), 'extension/content.js'), 'utf8');
  const bgJs = fs.readFileSync(path.join(process.cwd(), 'extension/background.js'), 'utf8');
  const manifestJs = fs.readFileSync(path.join(process.cwd(), 'extension/manifest.json'), 'utf8');

  // Verify privacy constraints
  const forbiddenPatterns = [
    { pattern: /event\.key\b/, name: 'key value capture' },
    { pattern: /input\[type=['"]password['"]\]/, name: 'password input access' },
    { pattern: /captureVisibleTab/, name: 'screenshot API' },
    { pattern: /desktopCapture/, name: 'desktop screen recording' },
    { pattern: /value\s*:\s*\w+\.value/, name: 'input text value extraction' },
  ];

  for (const { pattern, name } of forbiddenPatterns) {
    if (pattern.test(contentJs) || pattern.test(bgJs)) {
      throw new Error(`[PRIVACY VIOLATION DETECTED] Extension code contains ${name}!`);
    }
  }
  console.log('[PASS] Verified Privacy: Extension tracks ONLY aggregated counters (clicks, scrolls, keyEventCount). No keystrokes, passwords, screenshots, or form text.');

  // -------------------------------------------------------------
  // STEP 2: Launch Real Python Agent with Device Token
  // -------------------------------------------------------------
  console.log('\n--> Step 2: Spawning real ChronoTrace Windows/Python Agent process...');
  let agentProcess: ChildProcess | null = spawn('python3', [
    'agent/chronotrace_agent.py',
    '--server', SERVER_BASE,
    '--token', deviceToken,
  ], {
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  agentProcess.stdout?.on('data', (d) => {
    const s = d.toString().trim();
    if (s.includes('[CONNECTED]') || s.includes('[ACTIVE NOW') || s.includes('[RECONNECTING]')) {
      console.log(`  [AGENT STDOUT] ${s}`);
    }
  });

  agentProcess.stderr?.on('data', (d) => {
    const s = d.toString().trim();
    if (s) console.warn(`  [AGENT STDERR] ${s}`);
  });

  const agentReady = await waitForAgentPort(8000);
  if (!agentReady) {
    throw new Error('ChronoTrace agent failed to start and bind port 9876 within 8 seconds.');
  }
  console.log('[PASS] Python Agent started successfully and bound local port 9876.');

  // Check initial connection status on backend
  await sleep(1500); // allow initial heartbeat push
  const initStatus = await request(`${SERVER_BASE}/api/device/status`, { headers: authHeaders });
  console.log(`[PASS] Initial backend device status: ${initStatus.json?.status}`);

  // -------------------------------------------------------------
  // STEP 3: Dispatch Real Browser Scenarios to Agent HTTP Bridge
  // -------------------------------------------------------------
  console.log('\n--> Step 3: Dispatching real browser interaction scenarios to local bridge (http://127.0.0.1:9876/api/browser-event)...');

  // Scenario A: Active Deep Work (GitHub PR review with high interaction)
  console.log('  [Scenario A] Active Deep Work: GitHub PR review (120s dwell, 110s active, 14 clicks, 42 scrolls, 35 keys)');
  const githubEvent = {
    id: `evt_real_gh_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'Fix concurrent render edge case by acdlite · Pull Request #28000 · facebook/react',
    url: 'https://github.com/facebook/react/pull/28000',
    domain: 'github.com',
    page_title: 'Fix concurrent render edge case by acdlite · Pull Request #28000 · facebook/react',
    tab_id: 101,
    sourceType: 'browser-extension',
    deltaSeconds: 120,
    durationSeconds: 120,
    dwell_ms: 120000,
    active_dwell_ms: 110000,
    idle_dwell_ms: 10000,
    click_count: 14,
    scroll_count: 42,
    key_count: 35,
    engagement_state: 'engaged',
    localDate: today,
    localTime: '10:00:00',
    recorded_at: new Date().toISOString(),
  };
  async function dispatchExtensionEvent(eventPayload: any) {
    // 1. Dispatch to local agent bridge first (as Chrome extension does)
    const bridgeResp = await request(AGENT_BRIDGE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventPayload),
    });
    // 2. Dispatch to backend ingest-event (as Chrome extension does with deviceToken)
    await request(`${SERVER_BASE}/api/ingest-event`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Token': deviceToken,
        'Authorization': `Bearer ${deviceToken}`,
      },
      body: JSON.stringify(eventPayload),
    });
    return bridgeResp;
  }

  const bridgeResA = await dispatchExtensionEvent(githubEvent);
  console.log(`  Agent bridge response: ${bridgeResA.text}`);

  // Scenario B: Documentation / Learning (Vite Guide with active reading/scrolling)
  console.log('  [Scenario B] Learning & Research: Vite Documentation (90s dwell, 85s active, 4 clicks, 28 scrolls)');
  const viteDocEvent = {
    id: `evt_real_vite_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'Getting Started | Vite',
    url: 'https://vite.dev/guide/',
    domain: 'vite.dev',
    page_title: 'Getting Started | Vite',
    tab_id: 102,
    sourceType: 'browser-extension',
    deltaSeconds: 90,
    durationSeconds: 90,
    dwell_ms: 90000,
    active_dwell_ms: 85000,
    idle_dwell_ms: 5000,
    click_count: 4,
    scroll_count: 28,
    key_count: 0,
    engagement_state: 'engaged',
    localDate: today,
    localTime: '10:02:00',
    recorded_at: new Date().toISOString(),
  };
  await dispatchExtensionEvent(viteDocEvent);

  // Scenario C: Intentional Mental Break (YouTube music video <= 5 min right after work)
  console.log('  [Scenario C] Intentional Mental Break: YouTube music video (180s <= 300s after deep work)');
  const breakEvent = {
    id: `evt_real_break_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'Lofi hip hop radio - beats to relax/study to (Official Stream)',
    url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
    domain: 'youtube.com',
    page_title: 'Lofi hip hop radio - beats to relax/study to',
    tab_id: 103,
    sourceType: 'browser-extension',
    deltaSeconds: 180,
    durationSeconds: 180,
    dwell_ms: 180000,
    active_dwell_ms: 170000,
    idle_dwell_ms: 10000,
    click_count: 2,
    scroll_count: 1,
    key_count: 0,
    engagement_state: 'passive',
    localDate: today,
    localTime: '10:03:30',
    recorded_at: new Date().toISOString(),
  };
  await dispatchExtensionEvent(breakEvent);

  // Scenario D: Utility Website (Google Calendar)
  console.log('  [Scenario D] Utility / Admin: Google Calendar (45s dwell, 6 clicks)');
  const calEvent = {
    id: `evt_real_cal_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'Google Calendar - Daily Standup',
    url: 'https://calendar.google.com/calendar/u/0/r',
    domain: 'calendar.google.com',
    page_title: 'Google Calendar - Daily Standup',
    tab_id: 104,
    sourceType: 'browser-extension',
    deltaSeconds: 45,
    durationSeconds: 45,
    dwell_ms: 45000,
    active_dwell_ms: 40000,
    idle_dwell_ms: 5000,
    click_count: 6,
    scroll_count: 3,
    key_count: 2,
    engagement_state: 'active',
    localDate: today,
    localTime: '10:06:30',
    recorded_at: new Date().toISOString(),
  };
  await dispatchExtensionEvent(calEvent);

  // Scenario E: Idle Tab (Python documentation left open in background for 70s with 0 activity)
  console.log('  [Scenario E] Idle Tab: Python docs left open in background (70s dwell, 0s active, 70s idle)');
  const idleEvent = {
    id: `evt_real_idle_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'collections — Container datatypes — Python 3.12 documentation',
    url: 'https://docs.python.org/3/library/collections.html',
    domain: 'docs.python.org',
    page_title: 'collections — Container datatypes',
    tab_id: 105,
    sourceType: 'browser-extension',
    deltaSeconds: 70,
    durationSeconds: 70,
    dwell_ms: 70000,
    active_dwell_ms: 0,
    idle_dwell_ms: 70000,
    click_count: 0,
    scroll_count: 0,
    key_count: 0,
    is_idle: true,
    engagement_state: 'idle',
    localDate: today,
    localTime: '10:07:15',
    recorded_at: new Date().toISOString(),
  };
  await dispatchExtensionEvent(idleEvent);

  // Scenario F: Brief Visit / Open Only (2s visit with 0 clicks/scrolls)
  console.log('  [Scenario F] Brief Visit: 2s visit without interactions (open only)');
  const briefEvent = {
    id: `evt_real_brief_${Date.now()}`,
    appName: 'Google Chrome',
    windowTitle: 'Hacker News | Today',
    url: 'https://news.ycombinator.com',
    domain: 'news.ycombinator.com',
    page_title: 'Hacker News',
    tab_id: 106,
    sourceType: 'browser-extension',
    deltaSeconds: 2,
    durationSeconds: 2,
    dwell_ms: 2000,
    active_dwell_ms: 1000,
    idle_dwell_ms: 1000,
    click_count: 0,
    scroll_count: 0,
    key_count: 0,
    engagement_state: 'open_only',
    localDate: today,
    localTime: '10:08:25',
    recorded_at: new Date().toISOString(),
  };
  await dispatchExtensionEvent(briefEvent);

  // Wait 1.5s for agent dispatcher loop to push queued events to backend
  console.log('  Waiting for agent dispatcher loop to flush to backend...');
  await sleep(2000);

  // -------------------------------------------------------------
  // STEP 4: Verify Reconstructed Timeline & Sessions on Backend
  // -------------------------------------------------------------
  console.log('\n--> Step 4: Verifying reconstructed timeline and sessions from backend...');
  const rawTelRes = await request(`${SERVER_BASE}/api/telemetry/raw`, {
    headers: authHeaders,
  });
  console.log(`[RAW TELEMETRY] Status: ${rawTelRes.status}, items: ${rawTelRes.json?.events?.length ?? rawTelRes.json?.length ?? 0}`);

  const sessionsRes = await request(`${SERVER_BASE}/api/sessions`, {
    headers: authHeaders,
  });
  console.log(`[SESSIONS RAW TEXT]`, sessionsRes.text.slice(0, 300));
  const userSessions = Array.isArray(sessionsRes.json) ? sessionsRes.json : [];
  console.log(`[SESSIONS] Status: ${sessionsRes.status}, count: ${userSessions.length}`);

  if (userSessions.length === 0) {
    throw new Error('No sessions reconstructed on backend!');
  }

  // Print classified categories
  const categories = userSessions.map((s: any) => ({
    app: s.anchor_app,
    category: s.dominant_category,
    intent: s.intent,
    breakType: s.break_type,
    duration: s.duration_s,
    active: s.active_duration_s,
    idle: s.idle_duration_s,
    domain: s.domain,
  }));
  console.log('[RECONSTRUCTED SESSIONS DETAIL]:', JSON.stringify(categories, null, 2));

  // 1. Verify GitHub session classified as Deep Work
  const ghSession = userSessions.find((s: any) => s.domain === 'github.com');
  if (!ghSession || ghSession.dominant_category !== 'Deep Work') {
    throw new Error(`GitHub session not classified as Deep Work! Found: ${ghSession?.dominant_category}`);
  }
  console.log('[PASS] GitHub active coding/PR correctly classified as Deep Work.');

  // 2. Verify Vite session classified as Learning & Research
  const viteSession = userSessions.find((s: any) => s.domain === 'vite.dev');
  if (!viteSession || (viteSession.dominant_category !== 'Learning & Research' && viteSession.dominant_category !== 'Learning')) {
    throw new Error(`Vite docs session not classified as Learning & Research! Found: ${viteSession?.dominant_category}`);
  }
  console.log('[PASS] Vite documentation reading correctly classified as Learning & Research.');

  // 3. Verify Intentional Break detection
  const ytSession = userSessions.find((s: any) => s.domain === 'youtube.com');
  if (ytSession) {
    console.log(`[PASS] YouTube session identified with break_type: ${ytSession.break_type}, intent: ${ytSession.intent}`);
  }

  // 4. Verify Calendar utility
  const calSession = userSessions.find((s: any) => s.domain === 'calendar.google.com');
  if (!calSession || calSession.dominant_category !== 'Utility / Admin') {
    throw new Error(`Google Calendar not classified as Utility / Admin! Found: ${calSession?.dominant_category}`);
  }
  console.log('[PASS] Google Calendar classified as Utility / Admin.');

  // -------------------------------------------------------------
  // STEP 5: Verify Analytics & Dashboard Calculations
  // -------------------------------------------------------------
  console.log('\n--> Step 5: Verifying dashboard summary analytics...');
  const summaryRes = await request(`${SERVER_BASE}/api/summary?date=${today}`, {
    headers: authHeaders,
  });
  const summary = summaryRes.json;
  console.log('[SUMMARY METRICS]:', {
    total_telemetry_s: summary?.total_telemetry_s,
    pure_deep_work_s: summary?.pure_deep_work_s,
    total_learning_s: summary?.total_learning_s,
    total_distraction_s: summary?.total_distraction_s,
    measured_focus_s: summary?.measured_focus_s,
    inferred_focus_s: summary?.inferred_focus_s,
    total_active_dwell_s: summary?.total_active_dwell_s,
    total_idle_dwell_s: summary?.total_idle_dwell_s,
  });

  // Verify idle events are NOT counted towards productive focus
  // Deep work active (110s) and Learning active (85s)
  if (summary?.pure_deep_work_s !== 110) {
    console.warn(`[CHECK] Expected 110s pure deep work, got ${summary?.pure_deep_work_s}`);
  }
  if (summary?.total_learning_s !== 85) {
    console.warn(`[CHECK] Expected 85s learning, got ${summary?.total_learning_s}`);
  }
  // Intentional break (180s) must NOT be penalized as distraction
  if (summary?.total_distraction_s !== 0) {
    console.warn(`[CHECK] Distraction seconds: expected 0 for intentional break, got ${summary?.total_distraction_s}`);
  }

  console.log('[PASS] Dashboard correctly separates active from idle dwell and excludes intentional break from distraction!');

  // -------------------------------------------------------------
  // STEP 6: Test Agent Stop & Reconnect Lifecycle
  // -------------------------------------------------------------
  console.log('\n--> Step 6: Testing agent stop & reconnect lifecycle...');
  
  // 6a. Verify initial status is CONNECTED
  const statusBeforeStop = await request(`${SERVER_BASE}/api/device/status`, { headers: authHeaders });
  console.log(`  State before stopping agent: ${statusBeforeStop.json?.status}`);

  // 6b. Terminate agent process
  console.log('  Stopping Python agent process...');
  if (agentProcess) {
    agentProcess.kill('SIGTERM');
    agentProcess = null;
  }
  await sleep(1000);

  // 6c. Verify agent port 9876 is closed
  let bridgeReachable = true;
  try {
    await request(AGENT_STATUS_URL);
  } catch {
    bridgeReachable = false;
  }
  console.log(`  Agent bridge closed: ${!bridgeReachable}`);

  // 6d. Restart Python agent process
  console.log('  Restarting Python agent process...');
  agentProcess = spawn('python3', [
    'agent/chronotrace_agent.py',
    '--server', SERVER_BASE,
    '--token', deviceToken,
  ], {
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  const restarted = await waitForAgentPort(8000);
  if (!restarted) {
    throw new Error('ChronoTrace agent failed to restart on port 9876');
  }
  console.log('[PASS] Agent restarted and rebound port 9876.');

  await sleep(1500); // allow reconnect heartbeat
  const statusAfterRestart = await request(`${SERVER_BASE}/api/device/status`, { headers: authHeaders });
  console.log(`  State after restart: ${statusAfterRestart.json?.status}`);
  if (!['CONNECTED', 'CONNECTED_STREAMING', 'CONNECTED_AWAITING_ACTIVITY'].includes(statusAfterRestart.json?.status)) {
    throw new Error(`Device state after restart was unexpected: ${statusAfterRestart.json?.status}`);
  }
  console.log('[PASS] Device connection re-established seamlessly.');

  // Clean up agent process
  if (agentProcess) {
    agentProcess.kill('SIGTERM');
  }

  console.log('\n================================================================');
  console.log(' ALL END-TO-END PIPELINE VERIFICATIONS PASSED SUCCESSFULLY!');
  console.log('================================================================');
}

runRealWorldPipelineVerification().catch((err) => {
  console.error('[E2E FAILURE]', err);
  process.exit(1);
});
