import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Clock,
  AlertCircle,
  Loader2,
  Lock,
  User,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  ArrowLeft,
  UserPlus,
  LogIn,
  Check,
  Info,
  X,
} from 'lucide-react';
import { UserProfile } from '@shared/types/chronotrace';
import {
  PASSWORD_RULES,
  validateRegistration,
  type FieldErrors,
  type RegistrationField,
} from '@shared/validation/auth';
import { AuthApiError, getAuthConfig, postAuthJson } from '../lib/authApi';

type AuthMode = 'signin' | 'register';

interface AuthResponse {
  success: boolean;
  token?: string;
  user: UserProfile;
  isRegistered: boolean;
  hasConfiguredDevice: boolean;
}

interface GoogleAuthScreenProps {
  onSuccess: (user: UserProfile, isFirstTime?: boolean) => void;
  onBackToSplash?: () => void;
  initialMode?: AuthMode;
}

// Minimal typing for the Google Identity Services script (loaded from accounts.google.com).
interface GoogleIdentityApi {
  accounts: {
    id: {
      initialize: (config: {
        client_id: string;
        callback: (response: { credential?: string }) => void;
        auto_select?: boolean;
        cancel_on_tap_outside?: boolean;
      }) => void;
      renderButton: (element: HTMLElement, options: Record<string, unknown>) => void;
    };
  };
}

declare global {
  interface Window {
    google?: GoogleIdentityApi;
  }
}

let googleScriptPromise: Promise<void> | null = null;
const loadGoogleScript = (): Promise<void> => {
  if (window.google?.accounts?.id) return Promise.resolve();
  if (!googleScriptPromise) {
    googleScriptPromise = new Promise<void>((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.onload = () => resolve();
      script.onerror = () => {
        googleScriptPromise = null;
        script.remove();
        reject(new Error('The Google sign-in script could not be loaded.'));
      };
      document.head.appendChild(script);
    });
  }
  return googleScriptPromise;
};

const inputClass = (hasError: boolean) =>
  `w-full pl-9 pr-3 py-2.5 text-sm rounded-lg border bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-shadow ${
    hasError
      ? 'border-rose-400 focus:ring-rose-200 focus:border-rose-500'
      : 'border-slate-300 focus:ring-blue-500/30 focus:border-blue-500'
  }`;

interface FieldProps {
  id: string;
  label: string;
  error?: string;
  required?: boolean;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const Field: React.FC<FieldProps> = ({ id, label, error, required, icon, children }) => (
  <div>
    <label htmlFor={id} className="block text-xs font-medium text-slate-700 mb-1.5">
      {label}
      {required && <span className="text-rose-500"> *</span>}
    </label>
    <div className="relative">
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{icon}</span>
      {children}
    </div>
    {error && (
      <p id={`${id}-error`} className="mt-1.5 text-xs text-rose-600 flex items-start gap-1.5">
        <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-px" />
        <span>{error}</span>
      </p>
    )}
  </div>
);

const GoogleLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4 shrink-0' }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
  </svg>
);

export const GoogleAuthScreen: React.FC<GoogleAuthScreenProps> = ({
  onSuccess,
  onBackToSplash,
  initialMode = 'signin',
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Sign-in form
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginSubmitted, setLoginSubmitted] = useState(false);

  // Registration form
  const [regForm, setRegForm] = useState({
    name: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [regTouched, setRegTouched] = useState<Partial<Record<RegistrationField, boolean>>>({});
  const [regSubmitted, setRegSubmitted] = useState(false);
  const [serverFieldErrors, setServerFieldErrors] = useState<FieldErrors>({});
  const [passwordFocused, setPasswordFocused] = useState(false);

  // Google sign-in state
  const [googleClientId, setGoogleClientId] = useState<string | null>(null);
  const [googleConfigLoaded, setGoogleConfigLoaded] = useState(false);
  const [googleError, setGoogleError] = useState<string | null>(null);
  const [googleAuthError, setGoogleAuthError] = useState<string | null>(null);
  const [showGoogleNotice, setShowGoogleNotice] = useState(false);
  const [googleReady, setGoogleReady] = useState(false);
  const googleButtonRef = useRef<HTMLDivElement>(null);
  const onSuccessRef = useRef(onSuccess);
  onSuccessRef.current = onSuccess;

  // Sync mode whenever initialMode prop changes (e.g. navigation from splash buttons)
  useEffect(() => {
    setMode(initialMode);
    setFormError(null);
    setGoogleAuthError(null);
    setServerFieldErrors({});
    setLoginSubmitted(false);
    setRegSubmitted(false);
    setRegTouched({});
    setShowGoogleNotice(false);
  }, [initialMode]);

  // Live registration validation, recomputed on every change.
  const regLive = useMemo(() => validateRegistration(regForm).errors, [regForm]);
  const regShown = (field: RegistrationField): string | undefined => {
    if (!regTouched[field] && !regSubmitted) return serverFieldErrors[field];
    return serverFieldErrors[field] ?? regLive[field];
  };

  const passwordChecks = PASSWORD_RULES.map((rule) => ({
    ...rule,
    met: rule.test(regForm.password),
  }));

  useEffect(() => {
    let cancelled = false;
    getAuthConfig().then((config) => {
      if (cancelled) return;
      setGoogleClientId(config.googleClientId);
      setGoogleConfigLoaded(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleGoogleCredential = async (response: { credential?: string }) => {
    if (!response.credential) {
      setGoogleAuthError('Google did not return a sign-in credential. Please try again.');
      return;
    }
    setGoogleAuthError(null);
    setLoading(true);
    try {
      const data = await postAuthJson<AuthResponse>('/api/auth/google', { credential: response.credential });
      onSuccessRef.current(data.user, !data.isRegistered);
    } catch (err) {
      setGoogleAuthError(err instanceof Error ? err.message : 'Google sign-in failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  const googleCredentialRef = useRef(handleGoogleCredential);
  googleCredentialRef.current = handleGoogleCredential;

  // Load Google Identity Services once a client ID is configured, then render the official button.
  useEffect(() => {
    if (!googleClientId) return;
    let cancelled = false;
    setGoogleError(null);
    loadGoogleScript()
      .then(() => {
        if (cancelled || !window.google) return;
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: (response) => {
            void googleCredentialRef.current(response);
          },
          auto_select: false,
          cancel_on_tap_outside: true,
        });
        setGoogleReady(true);
      })
      .catch((err: Error) => {
        if (!cancelled) setGoogleError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [googleClientId]);

  // Re-render the Google button whenever the mode changes so its label matches.
  useEffect(() => {
    const container = googleButtonRef.current;
    if (!googleReady || !container || !window.google) return;
    container.innerHTML = '';
    window.google.accounts.id.renderButton(container, {
      type: 'standard',
      theme: 'outline',
      size: 'large',
      text: mode === 'signin' ? 'signin_with' : 'signup_with',
      shape: 'rectangular',
      logo_alignment: 'left',
      width: Math.min(container.clientWidth || 340, 400),
    });
  }, [googleReady, mode]);

  const switchMode = (next: AuthMode) => {
    setMode(next);
    setFormError(null);
    setGoogleAuthError(null);
    setServerFieldErrors({});
    setLoginSubmitted(false);
    setRegSubmitted(false);
    setRegTouched({});
    setShowGoogleNotice(false);
  };

  const focusFirstInvalid = (errors: Partial<Record<string, string>>, order: string[]) => {
    const first = order.find((key) => errors[key]);
    if (first) document.getElementById(`reg-${first}`)?.focus();
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setLoginSubmitted(true);
    if (!loginIdentifier.trim() || !loginPassword) return;

    setLoading(true);
    try {
      const data = await postAuthJson<AuthResponse>('/api/auth/login', {
        username: loginIdentifier.trim(),
        // Passwords are sent exactly as typed. Leading or trailing spaces are part of the password.
        password: loginPassword,
      });
      onSuccess(data.user, false);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Sign-in failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setRegSubmitted(true);
    const result = validateRegistration(regForm);
    if (!result.valid) {
      focusFirstInvalid(result.errors, ['name', 'username', 'email', 'password', 'confirmPassword']);
      return;
    }

    setLoading(true);
    try {
      const data = await postAuthJson<AuthResponse>('/api/auth/register', {
        name: regForm.name,
        username: regForm.username,
        email: regForm.email,
        password: regForm.password,
        confirmPassword: regForm.confirmPassword,
      });
      onSuccess(data.user, true);
    } catch (err) {
      if (err instanceof AuthApiError && err.fieldErrors && Object.keys(err.fieldErrors).length > 0) {
        // The message belongs to the field itself, so the banner only points at the fields.
        setServerFieldErrors(err.fieldErrors);
        focusFirstInvalid(err.fieldErrors, ['name', 'username', 'email', 'password', 'confirmPassword']);
        setFormError('Please fix the highlighted fields and try again.');
      } else {
        setFormError(err instanceof Error ? err.message : 'Account creation failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const updateReg = (field: RegistrationField, value: string) => {
    setRegForm((prev) => ({ ...prev, [field]: value }));
    setServerFieldErrors((prev) => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };
  const touchReg = (field: RegistrationField) => setRegTouched((prev) => ({ ...prev, [field]: true }));

  const loginIdentifierError = loginSubmitted && !loginIdentifier.trim() ? 'Enter your username or email.' : undefined;
  const loginPasswordError = loginSubmitted && !loginPassword ? 'Enter your password.' : undefined;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50/40 flex flex-col justify-center items-center px-4 py-10 font-sans">
      <div className="w-full max-w-[440px] bg-white border border-slate-200/80 rounded-2xl shadow-xl shadow-slate-900/5 p-7 sm:p-9 relative">
        {onBackToSplash && (
          <button
            type="button"
            onClick={onBackToSplash}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer mb-4 -ml-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        )}

        <div className="flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/20 mb-4">
            <Clock className="w-6 h-6 stroke-[2.2]" />
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {mode === 'signin' ? 'Welcome back' : 'Create your account'}
          </h1>
          <p className="text-xs text-slate-500 mt-1.5 mb-6 leading-relaxed max-w-xs">
            {mode === 'signin'
              ? 'Sign in to your ChronoTrace timeline.'
              : 'Set up a ChronoTrace account to start reconstructing your day.'}
          </p>
        </div>

        {/* Mode switch */}
        <div role="tablist" className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl mb-6 text-xs font-medium">
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'signin'}
            onClick={() => switchMode('signin')}
            className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              mode === 'signin' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'register'}
            onClick={() => switchMode('register')}
            className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              mode === 'register' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Create Account</span>
          </button>
        </div>

        {/* Google sign-in (isolated from email/password authentication) */}
        <div>
          {googleClientId ? (
            <div>
              <div ref={googleButtonRef} className="flex justify-center min-h-[44px]" aria-label="Sign in with Google" />
              {!googleReady && !googleError && (
                <div className="flex items-center justify-center gap-2 min-h-[44px] text-xs text-slate-500">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Loading Google sign-in…</span>
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowGoogleNotice((prev) => !prev)}
              className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-700 font-medium text-sm shadow-sm transition-all cursor-pointer"
              aria-label={mode === 'signin' ? 'Sign in with Google' : 'Sign up with Google'}
            >
              <GoogleLogoIcon />
              <span>{mode === 'signin' ? 'Sign in with Google' : 'Sign up with Google'}</span>
            </button>
          )}

          {/* Non-blocking Google notice shown only when user interacts with Google auth */}
          {showGoogleNotice && !googleClientId && (
            <div className="mt-2.5 p-3 rounded-xl border bg-slate-50 border-slate-200 text-slate-600 text-xs flex items-start justify-between gap-2 leading-relaxed">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-600" />
                <span>
                  Google sign-in is not configured on this server yet (<code>GOOGLE_CLIENT_ID</code> not set). You can sign in or create an account using email and password below.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowGoogleNotice(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer p-0.5 shrink-0"
                aria-label="Dismiss notice"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Google auth error banner */}
          {(googleAuthError || googleError) && (
            <div className="mt-2.5 p-3 rounded-xl border bg-amber-50 border-amber-200 text-amber-800 text-xs flex items-start justify-between gap-2 leading-relaxed">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                <span>{googleAuthError || googleError}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setGoogleAuthError(null);
                  setGoogleError(null);
                }}
                className="text-amber-600 hover:text-amber-800 cursor-pointer p-0.5 shrink-0"
                aria-label="Dismiss error"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-slate-200" />
          <span className="text-[11px] text-slate-400 font-medium uppercase tracking-wider">or with email</span>
          <div className="flex-1 h-px bg-slate-200" />
        </div>

        {/* Email & password authentication error banner */}
        {formError && (
          <div role="alert" className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
            <span className="font-medium leading-relaxed">{formError}</span>
          </div>
        )}

        {mode === 'signin' ? (
          <form onSubmit={handleSignIn} noValidate className="space-y-4">
            <Field
              id="login-identifier"
              label="Username or email"
              required
              error={loginIdentifierError}
              icon={<User className="w-4 h-4" />}
            >
              <input
                id="login-identifier"
                type="text"
                autoComplete="username"
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="username or name@example.com"
                aria-invalid={Boolean(loginIdentifierError)}
                className={inputClass(Boolean(loginIdentifierError))}
              />
            </Field>

            <Field id="login-password" label="Password" required error={loginPasswordError} icon={<Lock className="w-4 h-4" />}>
              <input
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="Enter your password"
                aria-invalid={Boolean(loginPasswordError)}
                className={`${inputClass(Boolean(loginPasswordError))} pr-10`}
              />
              <PasswordToggle show={showPassword} onToggle={() => setShowPassword((v) => !v)} />
            </Field>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium py-2.5 px-4 rounded-xl shadow-sm transition-colors text-sm cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                <>
                  <span>Sign in</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
            <p className="text-center text-xs text-slate-500 pt-1">
              New to ChronoTrace?{' '}
              <button type="button" onClick={() => switchMode('register')} className="font-semibold text-blue-600 hover:text-blue-700 cursor-pointer">
                Create an account
              </button>
            </p>
          </form>
        ) : (
          <form onSubmit={handleRegister} noValidate className="space-y-4">
            <Field id="reg-name" label="Full name" required error={regShown('name')} icon={<User className="w-4 h-4" />}>
              <input
                id="reg-name"
                type="text"
                autoComplete="name"
                value={regForm.name}
                onChange={(e) => updateReg('name', e.target.value)}
                onBlur={() => touchReg('name')}
                placeholder="e.g. Alex Morgan"
                aria-invalid={Boolean(regShown('name'))}
                className={inputClass(Boolean(regShown('name')))}
              />
            </Field>

            <Field id="reg-username" label="Username" required error={regShown('username')} icon={<User className="w-4 h-4" />}>
              <input
                id="reg-username"
                type="text"
                autoComplete="username"
                value={regForm.username}
                onChange={(e) => updateReg('username', e.target.value)}
                onBlur={() => touchReg('username')}
                placeholder="3–20 letters, numbers or _"
                aria-invalid={Boolean(regShown('username'))}
                className={inputClass(Boolean(regShown('username')))}
              />
            </Field>

            <Field id="reg-email" label="Email address" required error={regShown('email')} icon={<Mail className="w-4 h-4" />}>
              <input
                id="reg-email"
                type="email"
                autoComplete="email"
                value={regForm.email}
                onChange={(e) => updateReg('email', e.target.value)}
                onBlur={() => touchReg('email')}
                placeholder="you@example.com"
                aria-invalid={Boolean(regShown('email'))}
                className={inputClass(Boolean(regShown('email')))}
              />
            </Field>

            <div>
              <Field id="reg-password" label="Password" required error={regShown('password')} icon={<Lock className="w-4 h-4" />}>
                <input
                  id="reg-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={regForm.password}
                  onChange={(e) => updateReg('password', e.target.value)}
                  onFocus={() => setPasswordFocused(true)}
                  onBlur={() => {
                    setPasswordFocused(false);
                    touchReg('password');
                  }}
                  placeholder="Create a strong password"
                  aria-invalid={Boolean(regShown('password'))}
                  className={`${inputClass(Boolean(regShown('password')))} pr-10`}
                />
                <PasswordToggle show={showPassword} onToggle={() => setShowPassword((v) => !v)} />
              </Field>
              {(passwordFocused || regForm.password.length > 0) && (
                <ul className="mt-2.5 grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-1.5" aria-label="Password requirements">
                  {passwordChecks.map((rule) => (
                    <li key={rule.id} className={`flex items-center gap-1.5 text-[11px] ${rule.met ? 'text-emerald-600' : 'text-slate-500'}`}>
                      <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center ${rule.met ? 'bg-emerald-100' : 'bg-slate-100'}`}>
                        {rule.met && <Check className="w-2.5 h-2.5" />}
                      </span>
                      <span>{rule.label}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <Field
              id="reg-confirmPassword"
              label="Confirm password"
              required
              error={regShown('confirmPassword')}
              icon={<Lock className="w-4 h-4" />}
            >
              <input
                id="reg-confirmPassword"
                type={showPassword ? 'text' : 'password'}
                autoComplete="new-password"
                value={regForm.confirmPassword}
                onChange={(e) => updateReg('confirmPassword', e.target.value)}
                onBlur={() => touchReg('confirmPassword')}
                placeholder="Re-enter your password"
                aria-invalid={Boolean(regShown('confirmPassword'))}
                className={`${inputClass(Boolean(regShown('confirmPassword')))} pr-10`}
              />
            </Field>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium py-2.5 px-4 rounded-xl shadow-sm transition-colors text-sm cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                <>
                  <span>Create account</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
            <p className="text-center text-xs text-slate-500 pt-1">
              Already have an account?{' '}
              <button type="button" onClick={() => switchMode('signin')} className="font-semibold text-blue-600 hover:text-blue-700 cursor-pointer">
                Sign in
              </button>
            </p>
          </form>
        )}
      </div>
    </div>
  );
};

// Kept as a separate component so the eye button sits inside the relative wrapper.
const PasswordToggle: React.FC<{ show: boolean; onToggle: () => void }> = ({ show, onToggle }) => (
  <button
    type="button"
    onClick={onToggle}
    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
    aria-label={show ? 'Hide password' : 'Show password'}
  >
    {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
  </button>
);
