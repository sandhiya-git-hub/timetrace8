# ChronoTrace Browser Sensor (Chrome / Edge / Brave Extension)

The ChronoTrace Browser Sensor provides meaningful browser telemetry and privacy-safe engagement measurement.

### Capabilities:
- **Active Tab Tracking**: Detects exact web page domain, URL path, and page title.
- **Engagement Detection**: Aggregates interaction signals (clicks, scroll volume, and typing counts).
- **Distinguishes Usage from Merely Opening**: Measures active dwell time vs idle dwell time. An open tab left in the background or idle for > 30 seconds is not counted as productive focus.
- **Zero Privacy Invasion**: Never reads, stores, or transmits typed characters, passwords, form entries, DOM content, or private messages.

### How to Install (Takes 30 seconds):
1. Open Google Chrome, Microsoft Edge, or Brave.
2. Navigate to `chrome://extensions` (or `edge://extensions` in Edge).
3. Toggle on **Developer mode** in the top-right corner.
4. Click **Load unpacked**.
5. Select the `extension` folder inside this project.
6. Click the ChronoTrace extension icon in your browser toolbar, enter your **Device Token** (found in ChronoTrace -> Device Settings), and click **Save & Link Sensor**.
