document.addEventListener('DOMContentLoaded', () => {
  const serverUrlInput = document.getElementById('serverUrl');
  const deviceTokenInput = document.getElementById('deviceToken');
  const saveBtn = document.getElementById('saveBtn');
  const pauseToggleBtn = document.getElementById('pauseToggleBtn');
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  const tabTitle = document.getElementById('tabTitle');
  const tabDomain = document.getElementById('tabDomain');
  const activeDwell = document.getElementById('activeDwell');
  const idleDwell = document.getElementById('idleDwell');
  const interactionCount = document.getElementById('interactionCount');

  let currentConfig = {};

  function formatSec(ms) {
    const s = Math.round((ms || 0) / 1000);
    return `${s}s`;
  }

  function refreshStatus() {
    chrome.runtime.sendMessage({ type: 'GET_SENSOR_STATUS' }, (res) => {
      if (chrome.runtime.lastError || !res) return;

      currentConfig = res.config || {};
      serverUrlInput.value = currentConfig.serverUrl || '';
      deviceTokenInput.value = currentConfig.deviceToken || '';

      if (currentConfig.paused) {
        statusBadge.className = 'status-badge paused';
        statusText.textContent = 'Paused';
        pauseToggleBtn.textContent = 'Resume Sensor';
      } else {
        statusBadge.className = 'status-badge';
        statusText.textContent = 'Active';
        pauseToggleBtn.textContent = 'Pause Sensor';
      }

      const tab = res.activeTab || {};
      tabTitle.textContent = tab.title || 'No active web tab';
      tabDomain.textContent = tab.domain || 'Desktop / System Window';
      activeDwell.textContent = formatSec(tab.activeDwellMs);
      idleDwell.textContent = formatSec(tab.idleDwellMs);
      const totalInteractions = (tab.clicks || 0) + (tab.scrolls || 0) + (tab.keyEvents || 0);
      interactionCount.textContent = totalInteractions;
    });
  }

  saveBtn.addEventListener('click', () => {
    const serverUrl = serverUrlInput.value.trim();
    const deviceToken = deviceTokenInput.value.trim();

    chrome.runtime.sendMessage(
      {
        type: 'UPDATE_CONFIG',
        config: { serverUrl, deviceToken },
      },
      () => {
        saveBtn.textContent = 'Saved!';
        setTimeout(() => {
          saveBtn.textContent = 'Save & Link Sensor';
        }, 1500);
        refreshStatus();
      }
    );
  });

  pauseToggleBtn.addEventListener('click', () => {
    const newPaused = !currentConfig.paused;
    chrome.runtime.sendMessage(
      {
        type: 'UPDATE_CONFIG',
        config: { paused: newPaused },
      },
      () => {
        refreshStatus();
      }
    );
  });

  refreshStatus();
  setInterval(refreshStatus, 1500);
});
