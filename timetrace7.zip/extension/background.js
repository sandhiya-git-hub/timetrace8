/**
 * ChronoTrace Browser Sensor - Background Service Worker (Manifest V3)
 * 
 * Manages active tab state, calculates real active/idle durations,
 * aggregates privacy-safe engagement signals, and delivers browser telemetry
 * to the ChronoTrace Windows agent and backend.
 */

const DEFAULT_SERVER = 'https://ais-dev-eb2x2rmzg2jcenpj7f23os-382774727422.asia-southeast1.run.app';
const AGENT_BRIDGE_URL = 'http://127.0.0.1:9876/api/browser-event';

let activeTabState = {
  tabId: null,
  url: '',
  domain: '',
  title: '',
  startTime: Date.now(),
  lastTickTime: Date.now(),
  activeDwellMs: 0,
  idleDwellMs: 0,
  clicks: 0,
  scrolls: 0,
  keyEvents: 0,
  isIdle: false,
};

let config = {
  serverUrl: DEFAULT_SERVER,
  deviceToken: '',
  paused: false,
};

// Load saved config
chrome.storage.local.get(['serverUrl', 'deviceToken', 'paused'], (stored) => {
  if (stored.serverUrl) config.serverUrl = stored.serverUrl;
  if (stored.deviceToken) config.deviceToken = stored.deviceToken;
  if (stored.paused !== undefined) config.paused = stored.paused;
});

// Extract clean domain
function getDomain(rawUrl) {
  if (!rawUrl) return '';
  try {
    const u = new URL(rawUrl);
    return u.hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
}

// Flush current tab telemetry as completed event
async function flushActiveTab(reason = 'tab_switch') {
  if (!activeTabState.url || activeTabState.url.startsWith('chrome://') || activeTabState.url.startsWith('edge://')) {
    return;
  }

  const now = Date.now();
  const totalDwellMs = (activeTabState.activeDwellMs + activeTabState.idleDwellMs) || (now - activeTabState.startTime);
  const totalDwellSec = Math.max(1, Math.round(totalDwellMs / 1000));
  const activeSec = Math.round(activeTabState.activeDwellMs / 1000);
  const idleSec = Math.round(activeTabState.idleDwellMs / 1000);

  const eventPayload = {
    id: `evt_browser_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    appName: 'Google Chrome',
    windowTitle: activeTabState.title || activeTabState.domain || 'Browser Tab',
    url: activeTabState.url,
    domain: activeTabState.domain,
    page_title: activeTabState.title,
    tab_id: activeTabState.tabId,
    sourceType: 'browser-extension',
    deltaSeconds: totalDwellSec,
    durationSeconds: totalDwellSec,
    dwell_ms: totalDwellMs,
    active_dwell_ms: activeTabState.activeDwellMs,
    idle_dwell_ms: activeTabState.idleDwellMs,
    click_count: activeTabState.clicks,
    scroll_count: activeTabState.scrolls,
    key_count: activeTabState.keyEvents,
    engagement_state: activeTabState.isIdle ? 'idle' : (activeTabState.clicks > 0 || activeTabState.scrolls > 2) ? 'active' : 'passive',
    localDate: new Date().toISOString().split('T')[0],
    localTime: new Date().toLocaleTimeString(),
    recorded_at: new Date().toISOString(),
  };

  // Dispatch to local agent bridge first
  try {
    await fetch(AGENT_BRIDGE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventPayload),
    }).catch(() => {});
  } catch {}

  // Dispatch to remote backend if device token configured
  if (config.deviceToken && !config.paused) {
    try {
      const endpoint = `${config.serverUrl.replace(/\/$/, '')}/api/ingest-event`;
      await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-Token': config.deviceToken,
          Authorization: `Bearer ${config.deviceToken}`,
        },
        body: JSON.stringify(eventPayload),
      }).catch(() => {});
    } catch {}
  }
}

// Reset state for new active tab
function switchToTab(tabId, url, title) {
  if (activeTabState.tabId === tabId && activeTabState.url === url) {
    if (title && title !== activeTabState.title) {
      activeTabState.title = title;
    }
    return;
  }

  // Flush previous tab
  flushActiveTab('tab_switch');

  activeTabState = {
    tabId,
    url: url || '',
    domain: getDomain(url),
    title: title || '',
    startTime: Date.now(),
    lastTickTime: Date.now(),
    activeDwellMs: 0,
    idleDwellMs: 0,
    clicks: 0,
    scrolls: 0,
    keyEvents: 0,
    isIdle: false,
  };
}

// Tab switched
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab && tab.url) {
      switchToTab(tab.id, tab.url, tab.title);
    }
  } catch {}
});

// Tab navigation or URL changed
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.title) {
    if (activeTabState.tabId === tabId) {
      switchToTab(tabId, tab.url || changeInfo.url, tab.title || changeInfo.title);
    }
  }
});

// Browser window focus change
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // Browser lost focus (user moved to another app or desktop)
    flushActiveTab('window_blur');
  } else {
    // Browser gained focus
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId });
      if (tab && tab.url) {
        switchToTab(tab.id, tab.url, tab.title);
      }
    } catch {}
  }
});

// Receive engagement pings from content.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'CHRONOTRACE_ENGAGEMENT_PING') {
    if (sender.tab && sender.tab.id === activeTabState.tabId) {
      activeTabState.clicks += (msg.clicks || 0);
      activeTabState.scrolls += (msg.scrolls || 0);
      activeTabState.keyEvents += (msg.keyEvents || 0);
      activeTabState.activeDwellMs += (msg.activeDwellMs || 0);
      activeTabState.idleDwellMs += (msg.idleDwellMs || 0);
      activeTabState.isIdle = Boolean(msg.isCurrentlyIdle);
      if (msg.title) activeTabState.title = msg.title;
      if (msg.url) activeTabState.url = msg.url;
      activeTabState.domain = getDomain(msg.url);
    }
    sendResponse({ received: true });
  } else if (msg.type === 'GET_SENSOR_STATUS') {
    sendResponse({
      config,
      activeTab: activeTabState,
    });
  } else if (msg.type === 'UPDATE_CONFIG') {
    config = { ...config, ...msg.config };
    chrome.storage.local.set(config);
    sendResponse({ success: true, config });
  }
  return true;
});

// Periodic heartbeat / ongoing tab dwell flush every 5 seconds
setInterval(() => {
  if (activeTabState.url && !config.paused) {
    const totalMs = activeTabState.activeDwellMs + activeTabState.idleDwellMs;
    if (totalMs >= 5000) {
      flushActiveTab('periodic_interval');
    }
  }
}, 5000);
