import fs from 'fs';
import path from 'path';
import { DATA_DIR } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent } from '../../../shared/types/chronotrace.js';
import type { DeviceRecord } from '../types/models.js';

export function getUserDir(userId: string): string {
  const dir = path.join(DATA_DIR, 'users', userId);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}


export const defaultDeviceRecord: DeviceRecord = {
  paused: false,
  deviceName: 'Windows Workstation',
  os: 'Windows 11 64-bit',
  agentVersion: '1.3.0',
  samplingInterval: '500ms',
  lastHeartbeatAt: null,
  connectedSince: null,
  lastSuccessfulConnectionAt: null,
  lastEventTime: null,
  lastLocalDate: null,
};

export const HEARTBEAT_TIMEOUT_MS = 20_000;
export const RECONNECT_TIMEOUT_MS = 60_000;

export const isAgentLive = (rec: DeviceRecord, nowMs: number = Date.now()): boolean =>
  !rec.paused &&
  !!rec.lastHeartbeatAt &&
  nowMs - Date.parse(rec.lastHeartbeatAt) <= HEARTBEAT_TIMEOUT_MS;

export function getUserDeviceRecord(userId: string): DeviceRecord {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    if (fs.existsSync(devFile)) {
      const stored = JSON.parse(fs.readFileSync(devFile, 'utf-8'));
      return { ...defaultDeviceRecord, ...stored };
    }
  } catch {}
  return { ...defaultDeviceRecord };
}

export function saveUserDeviceRecord(userId: string, rec: DeviceRecord) {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    fs.writeFileSync(devFile, JSON.stringify(rec, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save device state for user ${userId}:`, e);
  }
}

export function getUserTelemetry(userId: string): TelemetryEvent[] {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

export function saveUserTelemetry(userId: string, events: TelemetryEvent[]) {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    fs.writeFileSync(file, JSON.stringify(events, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save telemetry for user ${userId}:`, e);
  }
}

export function getUserEventIndex(userId: string): Set<string> {
  const file = path.join(getUserDir(userId), 'event_index.json');
  try {
    if (fs.existsSync(file)) {
      const arr = JSON.parse(fs.readFileSync(file, 'utf-8'));
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch {}
  const telem = getUserTelemetry(userId);
  const set = new Set<string>();
  telem.forEach((e) => {
    if (e.id) set.add(e.id);
    if (e.date && e.timestamp && e.app_name && e.window_title) {
      set.add(`${e.date}:::${e.timestamp}:::${e.app_name}:::${e.window_title}`);
    }
  });
  return set;
}

export function saveUserEventIndex(userId: string, indexSet: Set<string>) {
  const file = path.join(getUserDir(userId), 'event_index.json');
  try {
    fs.writeFileSync(file, JSON.stringify(Array.from(indexSet)), 'utf-8');
  } catch (e) {
    console.error(`Could not save event index for user ${userId}:`, e);
  }
}

export function getUserSessions(userId: string): ChunkSummary[] {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    if (fs.existsSync(file)) {
      const sessions: ChunkSummary[] = JSON.parse(fs.readFileSync(file, 'utf-8'));
      const devFile = path.join(getUserDir(userId), 'device.json');
      if (sessions.length > 0 && fs.existsSync(devFile)) {
        try {
          const devRec: DeviceRecord = JSON.parse(fs.readFileSync(devFile, 'utf-8'));
          if (!isAgentLive(devRec)) {
            const last = sessions[sessions.length - 1];
            if (last && (last.closed_by === 'ACTIVE' || !last.closed_by)) {
              last.closed_by = 'AGENT_DISCONNECTED';
              if (devRec.lastEventTime) {
                last.end_time = devRec.lastEventTime;
              } else if (devRec.lastHeartbeatAt) {
                last.end_time = new Date(devRec.lastHeartbeatAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                });
              }
              // Persist the capped session to disk so storage remains consistent
              saveUserSessions(userId, sessions);
            }
          }
        } catch {}
      }
      return sessions;
    }
  } catch {}
  return [];
}

export function saveUserSessions(userId: string, sessions: ChunkSummary[]) {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    fs.writeFileSync(file, JSON.stringify(sessions, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save sessions for user ${userId}:`, e);
  }
}

export function getUserSummary(userId: string): DailySynthesis {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return {
    date: new Date().toISOString().split('T')[0],
    total_deep_work_s: 0,
    total_distraction_s: 0,
    total_telemetry_s: 0,
    fragmentation_score: 0,
    peak_focus_window: 'No activity yet',
    context_switches: 0,
    distraction_triggers: [],
    daily_narrative: 'Waiting for activity collection from your Windows agent.',
    unfinished_work: [],
    work_state: 'settled',
  };
}

export function saveUserSummary(userId: string, summary: DailySynthesis) {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    fs.writeFileSync(file, JSON.stringify(summary, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save summary for user ${userId}:`, e);
  }
}

export interface UserPreferenceRule {
  id: string;
  appPattern?: string;
  titlePattern?: string;
  category: 'Deep Work' | 'Learning & Research' | 'Communication' | 'Entertainment' | 'Utility / Admin' | 'Unclassified';
  intent: string;
  createdAt: string;
}

export function getUserPreferences(userId: string): UserPreferenceRule[] {
  const file = path.join(getUserDir(userId), 'preferences.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

export function saveUserPreferences(userId: string, prefs: UserPreferenceRule[]) {
  const file = path.join(getUserDir(userId), 'preferences.json');
  try {
    fs.writeFileSync(file, JSON.stringify(prefs, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save preferences for user ${userId}:`, e);
  }
}


