import express from 'express';
import path from 'path';
import { app } from './app.js';
import { IS_PRODUCTION, PORT, FRONTEND_DIST } from './config/env.js';

// In development the React app runs on its own Vite dev server (http://localhost:5173)
// and proxies /api to this server. In production this server also serves the built frontend.
if (IS_PRODUCTION) {
  app.use(express.static(FRONTEND_DIST));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(FRONTEND_DIST, 'index.html'));
  });
}

app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`ChronoTrace API running on port ${PORT}`);
  console.log(`  ➜  Local:   http://localhost:${PORT}/`);
  if (!IS_PRODUCTION) console.log('  ➜  Frontend dev server: http://localhost:5173/ (run `npm run dev` in /frontend)');
});
