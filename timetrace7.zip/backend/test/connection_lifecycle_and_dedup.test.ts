import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { app } from '../src/app.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../src/services/userStore.js';
import {
  getUserDir,
  getUserDeviceRecord,
  saveUserDeviceRecord,
  getUserTelemetry,
  saveUserTelemetry,
  getUserSessions,
  saveUserSessions,
  defaultDeviceRecord
} from '../src/services/dataStore.js';
import type { UserRecord } from '../src/types/models.js';

describe('ChronoTrace Connection Lifecycle, Deduplication, and Isolation Suite', () => {
  let server: Server;
  let base = '';

  const testUserId = 'usr_test_lifecycle_dedup';
  const testDeviceToken = 'ct_dev_test_token_secret_123';
  const testSessionToken = 'ct_sess_test_session_456';

  before(async () => {
    // Start local ephemeral HTTP server
    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address() as AddressInfo;
        base = `http://127.0.0.1:${addr.port}`;
        resolve();
      });
    });

    // Setup isolated test user
    const users = getUsers();
    const existingIdx = users.findIndex((u) => u.id === testUserId);
    const testUser: UserRecord = {
      id: testUserId,
      username: 'lifecycle_tester',
      email: 'tester@chronotrace.test',
      name: 'Lifecycle Tester',
      passwordHash: 'dummy_hash',
      deviceToken: testDeviceToken,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (existingIdx !== -1) {
      users[existingIdx] = testUser;
    } else {
      users.push(testUser);
    }
    saveUsers(users);

    // Setup auth session
    const authSessions = getAuthSessions();
    authSessions[testSessionToken] = {
      token: testSessionToken,
      userId: testUserId,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    };
    saveAuthSessions(authSessions);

    // Initialize clean user data
    saveUserDeviceRecord(testUserId, { ...defaultDeviceRecord });
    saveUserTelemetry(testUserId, []);
    saveUserSessions(testUserId, []);
  });

  after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    try {
      const users = getUsers().filter((u) => u.id !== testUserId);
      saveUsers(users);
      const authSessions = getAuthSessions();
      delete authSessions[testSessionToken];
      saveAuthSessions(authSessions);
      const userDir = getUserDir(testUserId);
      if (fs.existsSync(userDir)) {
        fs.rmSync(userDir, { recursive: true, force: true });
      }
    } catch {}
  });

  async function apiCall(method: string, url: string, headers: Record<string, string> = {}, body?: any) {
    const reqHeaders: Record<string, string> = { ...headers };
    if (body !== undefined) reqHeaders['Content-Type'] = 'application/json';
    const res = await fetch(base + url, {
      method,
      headers: reqHeaders,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json: any = text;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {}
    return { status: res.status, body: json };
  }

  const authHeaders = {
    Authorization: `Bearer ${testSessionToken}`,
  };
  const agentHeaders = {
    'X-Device-Token': testDeviceToken,
  };

  it('1. Initial state without agent: NOT_CONNECTED and disconnected', async () => {
    const res = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(res.status, 200);
    assert.equal(res.body.connected, false);
    assert.equal(res.body.status, 'NOT_CONNECTED');
    assert.match(res.body.statusText, /not started|paused/i);
  });

  it('2. Heartbeat arrival transitions device to CONNECTED', async () => {
    const nowIso = new Date().toISOString();
    const heartbeatRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      heartbeat: true,
      sourceType: 'heartbeat',
      utcTimestamp: nowIso,
      current: {
        appName: 'VS Code',
        windowTitle: 'agent.routes.ts - ChronoTrace',
        category: 'Deep Work',
        elapsedSeconds: 15,
      },
    });

    assert.equal(heartbeatRes.status, 200);
    assert.equal(heartbeatRes.body.status, 'ok');
    assert.equal(heartbeatRes.body.heartbeat, true);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, true);
    assert.equal(statusRes.body.status, 'CONNECTED_AWAITING_ACTIVITY');
    assert.equal(statusRes.body.currentForegroundApp, 'VS Code');
  });

  it('3. Real event ingestion updates telemetry, sessions, and transitions to CONNECTED streaming', async () => {
    const eventId = 'evt_test_window_101';
    const eventRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: eventId,
      appName: 'VS Code',
      windowTitle: 'server.ts - ChronoTrace',
      deltaSeconds: 45,
      overrideCategory: 'Deep Work',
      overrideTask: 'Working on backend server routes',
      localTime: '10:00:00 AM',
      localDate: '2026-10-29',
      sourceType: 'os-hook',
    });

    assert.equal(eventRes.status, 200);
    assert.equal(eventRes.body.ingested, 1);
    assert.equal(eventRes.body.duplicates, 0);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, true);
    assert.equal(statusRes.body.status, 'CONNECTED');
    assert.equal(statusRes.body.eventCount, 1);
  });

  it('4. Idempotency & Duplicate Prevention: Submitting the identical event twice does not double count', async () => {
    const eventId = 'evt_test_window_101'; // Same ID as above
    const duplicateRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: eventId,
      appName: 'VS Code',
      windowTitle: 'server.ts - ChronoTrace',
      deltaSeconds: 45,
      overrideCategory: 'Deep Work',
      overrideTask: 'Working on backend server routes',
      localTime: '10:00:00 AM',
      localDate: '2026-10-29',
      sourceType: 'os-hook',
    });

    assert.equal(duplicateRes.status, 200);
    assert.equal(duplicateRes.body.ingested, 0);
    assert.equal(duplicateRes.body.duplicates, 1);

    // Verify storage has exactly 1 event and duration remained 45 seconds
    const storedTelemetry = getUserTelemetry(testUserId);
    assert.equal(storedTelemetry.length, 1);
    assert.equal(storedTelemetry[0].id, eventId);

    const storedSessions = getUserSessions(testUserId);
    assert.equal(storedSessions.length, 1);
    assert.equal(storedSessions[0].duration_s, 45); // NOT doubled to 90!
  });

  it('5. Rejection of synthetic/test events in production telemetry', async () => {
    const testEvRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_simulated_fake_999',
      appName: 'Simulated App',
      windowTitle: 'Fake Test Window',
      deltaSeconds: 30,
      isTest: true,
    });

    assert.equal(testEvRes.status, 400);

    // Verify nothing added to telemetry
    const storedTelemetry = getUserTelemetry(testUserId);
    assert.equal(storedTelemetry.length, 1);
  });

  it('6. User and device isolation: wrong token fails with 401', async () => {
    const badTokenRes = await apiCall('POST', '/api/ingest-event', { 'X-Device-Token': 'ct_dev_invalid_nonexistent' }, {
      heartbeat: true,
    });

    assert.equal(badTokenRes.status, 401);
  });

  it('7. Lifecycle timeout: Agent stopped for 25s transitions to RECONNECTING', async () => {
    const devRec = getUserDeviceRecord(testUserId);
    // Simulate heartbeat from 25 seconds ago
    const past25s = new Date(Date.now() - 25_000).toISOString();
    devRec.lastHeartbeatAt = past25s;
    saveUserDeviceRecord(testUserId, devRec);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, false);
    assert.equal(statusRes.body.status, 'RECONNECTING');
    assert.match(statusRes.body.statusText, /reconnecting/i);
  });

  it('8. Lifecycle timeout: Agent stopped for 75s transitions to DISCONNECTED', async () => {
    const devRec = getUserDeviceRecord(testUserId);
    // Simulate heartbeat from 75 seconds ago
    const past75s = new Date(Date.now() - 75_000).toISOString();
    devRec.lastHeartbeatAt = past75s;
    saveUserDeviceRecord(testUserId, devRec);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, false);
    assert.equal(statusRes.body.status, 'DISCONNECTED');
    assert.match(statusRes.body.statusText, /disconnected/i);

    // Verify hanging active session is capped with AGENT_DISCONNECTED
    const sessions = getUserSessions(testUserId);
    assert.equal(sessions[0].closed_by, 'AGENT_DISCONNECTED');
  });

  it('9. Agent restart: Fresh heartbeat reconnects seamlessly', async () => {
    const freshIso = new Date().toISOString();
    const resumeRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      heartbeat: true,
      utcTimestamp: freshIso,
    });

    assert.equal(resumeRes.status, 200);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, true);
    assert.equal(statusRes.body.status, 'CONNECTED');
  });

  it('10. Analytics calculations: Summary accurately reflects real persisted data', async () => {
    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-29&endDate=2026-10-29', authHeaders);
    assert.equal(summaryRes.status, 200);
    assert.equal(summaryRes.body.total_telemetry_s, 45);
    assert.equal(summaryRes.body.total_deep_work_s, 45);
    assert.equal(summaryRes.body.total_distraction_s, 0);
    assert.equal(summaryRes.body.longest_session_s, 45);
    assert.equal(summaryRes.body.longest_session_app, 'VS Code');
    assert.equal(summaryRes.body.work_state, 'PRODUCTIVE');
  });
});
